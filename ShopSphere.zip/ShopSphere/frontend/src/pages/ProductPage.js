import React, { useEffect, useState } from 'react';
import axios from '../utils/api';

const ProductPage = () => {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        axios.get('/products')
            .then(response => setProducts(response.data))
            .catch(error => console.error('Error fetching products:', error));
    }, []);

    return (
        <div className="container">
            <h1>Product List</h1>
            <div className="product-grid">
                {products.map(product => (
                    <div key={product.id} className="card">
                        <h3>{product.name}</h3>
                        <p>{product.description}</p>
                        <p>Price: ${product.price}</p>
                        <button className="button">Add to Cart</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ProductPage;
