import React from 'react';

const CheckoutPage = () => {
    return (
        <div className="container">
            <h1>Checkout</h1>
            <p>Complete your purchase by providing your payment details.</p>
        </div>
    );
};

export default CheckoutPage;
