// src/components/Checkout.js
import React, { useState } from 'react';
import axios from 'axios';

function Checkout() {
  const [cardDetails, setCardDetails] = useState({ cardNumber: '', expiry: '', cvv: '' });
  
  const handlePayment = async () => {
    try {
      const response = await axios.post('http://localhost:5000/api/pay', cardDetails);
      alert(response.data.message);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <h2>Checkout</h2>
      <input type="text" placeholder="Card Number" onChange={(e) => setCardDetails({ ...cardDetails, cardNumber: e.target.value })} />
      <input type="text" placeholder="Expiry Date" onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })} />
      <input type="text" placeholder="CVV" onChange={(e) => setCardDetails({ ...cardDetails, cvv: e.target.value })} />
      <button onClick={handlePayment}>Pay</button>
    </div>
  );
}

export default Checkout;
