import React from 'react';

const AdminPage = () => {
    return (
        <div className="container">
            <h1>Admin Dashboard</h1>
            <p>Manage your products here.</p>
            {/* Additional product management features can be added */}
        </div>
    );
};

export default AdminPage;
