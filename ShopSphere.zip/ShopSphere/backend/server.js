{
    "name": "backend",
    "version": "1.0.0",
    "main": "index.js",
    "type": "module",
    "scripts": {
      "test": "echo \"Error: no test specified\" && exit 1",
      "start": "node server.js"
    },
    "keywords": [],
    "author": "",
    "license": "ISC",
    "description": "",
    "dependencies": {
      "express": "^4.21.0",
      "cors": "^2.8.5", 
      "dotenv": "^16.0.0", 
      "mongoose": "^7.0.0",     
      "nodemailer": "^6.9.1" 
    },
    "devDependencies": {}
  }
  