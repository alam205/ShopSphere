// src/components/AdminDashboard.js
import React, { useState } from 'react';
import axios from 'axios';

function AdminDashboard() {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');

  const handleAddProduct = async () => {
    try {
      const product = { name, description, price, stock };
      await axios.post('http://localhost:5000/api/products/add', product);
      alert('Product added successfully');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Product Name" />
      <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" />
      <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Price" />
      <input type="number" value={stock} onChange={(e) => setStock(e.target.value)} placeholder="Stock" />
      <button onClick={handleAddProduct}>Add Product</button>
    </div>
  );
}

export default AdminDashboard;
