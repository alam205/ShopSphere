import React from 'react';

const HomePage = () => {
    return (
        <div className="container">
            <h1>Welcome to the Shopping Web Application</h1>
            <p>Explore our wide range of products and find the best deals!</p>
        </div>
    );
};

export default HomePage;
