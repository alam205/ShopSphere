import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
    return (
        <div className="navbar">
            <Link to="/" style={{ margin: '0 10px', color: 'white' }}>Home</Link>
            <Link to="/products" style={{ margin: '0 10px', color: 'white' }}>Products</Link>
            <Link to="/admin" style={{ margin: '0 10px', color: 'white' }}>Admin</Link>
            <Link to="/checkout" style={{ margin: '0 10px', color: 'white' }}>Checkout</Link>
        </div>
    );
};

export default Navbar;
