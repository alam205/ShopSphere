import nodemailer from 'nodemailer';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

export const register = async (req, res) => {
  const { name, email, password, phoneNumber } = req.body;
  try {
    const user = new User({ name, email, password, phone: phoneNumber });
    const verificationToken = jwt.sign({ email }, 'emailSecret', { expiresIn: '1h' });
    user.verificationToken = verificationToken;

    await user.save();

    // Send verification email
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'your-email@gmail.com', // Replace with your email
        pass: 'your-email-password',  // Replace with your email password
      },
    });

    const mailOptions = {
      from: 'your-email@gmail.com',
      to: email,
      subject: 'Account Verification',
      text: `Please verify your account by clicking on the link: http://localhost:3000/verify/${verificationToken}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) return res.status(500).json({ error: 'Error sending verification email' });
      res.status(201).json({ message: 'User registered. Verification email sent.' });
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Verification logic
export const verifyEmail = async (req, res) => {
  const { token } = req.params;
  try {
    const decoded = jwt.verify(token, 'emailSecret');
    const user = await User.findOne({ email: decoded.email });
    if (!user) return res.status(404).json({ error: 'User not found' });

    user.isVerified = true;
    await user.save();
    res.json({ message: 'Account verified successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Invalid or expired token' });
  }
};
